package org.ice.math;

public class Ice2DVector {

	public int x;
	public int y;
	public int vx;
	public int vy;
}
